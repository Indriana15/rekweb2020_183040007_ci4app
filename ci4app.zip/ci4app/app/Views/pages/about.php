<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>About Me</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia magni accusantium labore consequuntur veritatis error tenetur animi dolore quibusdam, rem, sapiente facere modi molestias fuga, minima quidem! Sunt, distinctio. Mollitia!</p>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>